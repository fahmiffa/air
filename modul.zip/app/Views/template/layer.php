<?= $this->extend('template/base') ?>

<?= $this->section('content') ?>

<?= $this->include($con) ?>

<?= $this->endSection() ?>